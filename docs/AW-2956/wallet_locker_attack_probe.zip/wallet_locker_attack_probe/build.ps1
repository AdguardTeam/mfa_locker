param(
    [ValidateSet('Debug', 'Release')]
    [string]$Configuration = 'Release'
)

$ErrorActionPreference = 'Stop'

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$buildDir = Join-Path $scriptDir 'build'

Write-Host "Configuring attack probe in $buildDir"
cmake -S $scriptDir -B $buildDir -G 'Visual Studio 17 2022' -A x64

Write-Host "Building attack probe ($Configuration)"
cmake --build $buildDir --config $Configuration

$exePath = Join-Path $buildDir "$Configuration/wallet_locker_attack_probe.exe"
if (-not (Test-Path $exePath)) {
    throw "Expected executable was not produced: $exePath"
}

Write-Host "Built: $exePath"
